
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class IMCServlets extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String tmp = null; //variavel temporaria para converte String 
        float peso = 0; // variavel que irar receber o peso do form
        float altura = 0;   // variavel que irar receber o altura do form
        float resultadoimc = 0; // variavel que irar calcular o imc  com base na variavel peso e altura      

        tmp = request.getParameter("peso");
        peso = Float.parseFloat(tmp.replaceAll(",", ".")); // REPLACEALL, troca ',' por '.' 

        tmp = request.getParameter("altura");
        altura = Float.parseFloat(tmp.replaceAll(",", "."));

        resultadoimc = peso / (altura * altura);
        
        request.setAttribute("resultadoimc", resultadoimc);
        request.getRequestDispatcher("resultadoIMC.jsp").forward(request, response);

    }

}
